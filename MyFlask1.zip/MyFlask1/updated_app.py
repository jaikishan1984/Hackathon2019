#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 10:51:52 2019

@author: samsher
"""
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import sklearn.metrics
from pandas import DataFrame,Series
from sklearn.feature_extraction.text import TfidfVectorizer
from time import time
import nltk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
from nltk.stem import WordNetLemmatizer 
import gensim
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
import numpy as np

@app.route('/result',methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['name']
    url = message
    html = urlopen(url).read()
    soup = BeautifulSoup(html)
    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()    # rip it out
    # get text
    text = soup.get_text()
    text.strip()
    text.replace("\n"," ")
    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
    text.strip()
    text.replace("\n"," ")
    mydata = pd.read_csv((r"filtered_companies_data.csv"))
    X=mydata["description"].values
    corpus = []
    for i in range(0,len(X)):
        process_data = re.sub(r'\W', ' ', str(X[i]))
        process_data = process_data.lower()
        process_data= re.sub(r"[^A-Za-z0-9^,!.\/'+-=]", " ", process_data)
        process_data = re.sub(r"\'s", " ", process_data)
        process_data=re.sub(r'\d+'," ",process_data)
        process_data= re.sub("[^a-zA-Z]", " ",  process_data)
        process_data= re.sub(r'^br$', ' ', process_data)
        process_data = re.sub(r'\d', ' ', process_data)
        process_data= re.sub(r'\s+br\s+',' ',process_data)
        process_data = re.sub(r'\s+[a-z]\s+', ' ',process_data)
        process_data = re.sub(r'^b\s+', '', process_data)
        process_data= re.sub(r'\s+', ' ', process_data)
        corpus.append(process_data)
    all_words=[w.split() for w in corpus]
    all_flat_words=[ewords for words in all_words for ewords in words]
    from nltk.corpus import stopwords
    all_flat_words_ns=[w for w in all_flat_words if w not in stopwords.words("english")]
    set_nf=set(all_flat_words_ns)
    corpus_new=list(set_nf)
    corpus_new="".join(corpus_new)
    lemmatizer = WordNetLemmatizer()
    np.random.seed(400)
    '''
    Write a function to perform the pre processing steps on the entire dataset
    '''
    def lemmatize_stemming(text):
        return lemmatizer.lemmatize(text, pos='v')
    # Tokenize and lemmatize
    def preprocess(text):
        result=[]
        for token in gensim.utils.simple_preprocess(text) :
            if token not in gensim.parsing.preprocessing.STOPWORDS and len(token) > 3:
                result.append(lemmatize_stemming(token))
            
        return result
    words = []
    for word in corpus_new.split(' '):
        words.append(word)
    processed_docs = []

    for doc in X:
        processed_docs.append(preprocess(doc))
    
    dictionary = gensim.corpora.Dictionary(processed_docs)
    '''
    OPTIONAL STEP
    Remove very rare and very common words:
    
    - words appearing less than 15 times
    - words appearing in more than 10% of all documents
    '''
    dictionary.filter_extremes(no_below=15, no_above=0.1, keep_n= 100000)
    '''
    Create the Bag-of-words model for each document i.e for each document we create a dictionary reporting how many
    words and how many times those words appear. Save this to 'bow_corpus'
    '''
    bow_corpus = [dictionary.doc2bow(doc) for doc in processed_docs]
    '''
    Preview BOW for our sample preprocessed document
    '''
    document_num = 30
    bow_doc_x = bow_corpus[document_num]
    training_time_container={'b_naive_bayes':0,'mn_naive_bayes':0,'random_forest':0,'linear_svm':0}
    prediction_time_container={'b_naive_bayes':0,'mn_naive_bayes':0,'random_forest':0,'linear_svm':0}

    accuracy_container={'b_naive_bayes':0,'mn_naive_bayes':0,'random_forest':0,'linear_svm':0}
    vectorizer = TfidfVectorizer(stop_words='english')
    #Initializing TFIDF vectorizer to conver the raw corpus to a matrix of TFIDF features and also enabling the removal of stopwords.
    tfidf_matrix=vectorizer.fit_transform(corpus).todense()
    #creating TFIDF features sparse matrix by fitting it on the specified corpus. 
    tfidf_names=vectorizer.get_feature_names()
#   grabbing the name of the features.
    training_time_container.keys()
    variables = tfidf_matrix
    labels = mydata.company_category
    x_train, x_test, y_train, y_test  =   train_test_split(variables, labels, test_size=.3)
    from sklearn.naive_bayes import BernoulliNB
    #loading Gaussian Naive Bayes from the sklearn library:
    bnb_classifier=BernoulliNB()
    #initializing the object
    t0=time()
    bnb_classifier=bnb_classifier.fit(x_train,y_train)
    training_time_container['b_naive_bayes']=time()-t0
    #fitting the classifier or training the classifier on the training data
    #after the model has been trained, we proceed to test its performance on the test data:
    t0=time()
    bnb_predictions=bnb_classifier.predict(x_test)
    prediction_time_container['b_naive_bayes']=time()-t0
    nb_ascore=sklearn.metrics.accuracy_score(y_test, bnb_predictions)
    accuracy_container['b_naive_bayes']=nb_ascore
    print("Bernoulli Naive Bayes Accuracy Score: %f"%accuracy_container['b_naive_bayes'])
    print("Training Time: %f"%training_time_container['b_naive_bayes'])
    print("Prediction Time: %f"%prediction_time_container['b_naive_bayes'])
    print("Confusion Matrix of Bernoulli Naive Bayes Classifier output: ")
    sklearn.metrics.confusion_matrix(y_test,bnb_predictions)
    print("Classification Metrics: ")
    print(sklearn.metrics.classification_report(y_test,bnb_predictions))
    from sklearn.naive_bayes import MultinomialNB
    mn_bayes=MultinomialNB()
    t0=time()
    mn_bayes_fit=mn_bayes.fit(x_train,y_train)
    training_time_container['mn_naive_bayes']=time()-t0
    t0=time()
    prediction_mn=mn_bayes_fit.predict(x_test)
    prediction_time_container['mn_naive_bayes']=time()-t0
    mn_ascore=sklearn.metrics.accuracy_score(y_test, prediction_mn) 
    accuracy_container['mn_naive_bayes']=mn_ascore
    print("Accuracy Score of Multi-Nomial Naive Bayes: %f" %(mn_ascore))
    #and its training and prediction time are:
    print("Training Time: %fs"%training_time_container['mn_naive_bayes'])
    print("Prediction Time: %fs"%prediction_time_container['mn_naive_bayes'])
    from sklearn.ensemble import RandomForestClassifier

    rf_classifier=RandomForestClassifier(n_estimators=2)
    t0=time()
    rf_classifier=rf_classifier.fit(x_train,y_train)
    
    training_time_container['random_forest']=time()-t0
    print("Training Time: %fs"%training_time_container['random_forest'])
    
    t0=time()
    rf_predictions=rf_classifier.predict(x_test)
    prediction_time_container['random_forest']=time()-t0
    print("Prediction Time: %fs"%prediction_time_container['random_forest'])
    
    accuracy_container['random_forest']=sklearn.metrics.accuracy_score(y_test, rf_predictions)
    print ("Accuracy Score of Random Forests Classifier: ")
    print(accuracy_container['random_forest'])
    print(sklearn.metrics.confusion_matrix(y_test,rf_predictions))
    from sklearn import linear_model

    svm_classifier=linear_model.SGDClassifier(loss='hinge',alpha=0.0001)
    
    t0=time()
    svm_classifier=svm_classifier.fit(x_train, y_train)
    training_time_container['linear_svm']=time()-t0
    print("Training Time: %fs"%training_time_container['linear_svm'])
    
    t0=time()
    svm_predictions=svm_classifier.predict(x_test)
    prediction_time_container['linear_svm']=time()-t0
    print("Prediction Time: %fs"%prediction_time_container['linear_svm'])
    
    accuracy_container['linear_svm']=sklearn.metrics.accuracy_score(y_test, svm_predictions)
    print ("Accuracy Score of Linear SVM Classifier: %f"%accuracy_container['linear_svm'])
    print(sklearn.metrics.confusion_matrix(y_test,svm_predictions))
    
    svm_classifier_enet=linear_model.SGDClassifier(loss='hinge',alpha=0.0001,penalty='elasticnet')
    svm_classifier_enet=svm_classifier_enet.fit(x_train, y_train)
    
    svm_enet_predictions=svm_classifier_enet.predict(x_test)
    
    from sklearn.svm import SVC

    nl_svm_classifier=SVC(C=1000000.0, kernel='rbf')
    
    t0=time()
    nl_svm_classifier=nl_svm_classifier.fit(x_train,y_train)
    training_time_container['non_linear_svm']=time()-t0
    
    t0=time()
    nl_svm_predictions=nl_svm_classifier.predict(x_test)
    prediction_time_container['non_linear_svm']=time()-t0
    accuracy_container['non_linear_svm']=sklearn.metrics.accuracy_score(y_test,nl_svm_predictions)
    print("Accuracy score of Non-Linear SVM: %f"%accuracy_container['linear_svm'])
    
    import matplotlib.pyplot as plt
    with plt.style.context('fivethirtyeight'):
        plt.figure(figsize=(12,7))
        plt.bar(range(5),training_time_container.values(),align='center')
        plt.ylabel("Training time in seconds")
        plt.ylim(0,8)
        plt.grid(True)
        plt.title("Comparison of Training Time of different classifiers")
    
    with plt.style.context('fivethirtyeight'):
        plt.figure(figsize=(12,7))
        plt.bar(range(5),prediction_time_container.values(),align='center',color='orange')
        
        plt.ylabel("Prediction time in seconds")
        plt.grid(True)
        plt.ylim(0,1)
        plt.title("Comparison of Prediction Time of different classifiers")
    
    acc=accuracy_container.values()
    plt.figure(figsize=(12,7))
    plt.bar(accuracy_container.keys(),acc,align='center',color='g')
    
    alog_name=accuracy_container.keys()
    from sklearn.feature_selection import SelectKBest
    from sklearn.feature_selection import chi2
    X_new = SelectKBest(chi2, k=5000).fit_transform(variables,labels)
    cvariables_train, cvariables_test, clabels_train, clabels_test  =   train_test_split(X_new, labels, test_size=.3)
    
	#Alternative Usage of Saved Model
	# joblib.dump(clf, 'NB_spam_model.pkl')
	# NB_spam_model = open('NB_spam_model.pkl','rb')
	# clf = joblib.load(NB_spam_model)

    if request.method == 'POST':
        #name = request.form['name']
        data = [text]
        vect = vectorizer.transform(data).toarray()
        my_prediction = classifier.predict(vect)
        my_prediction1=list(my_prediction)
        st="".join(my_prediction1)
        #print(name)
    return render_template('result.html',result = st)