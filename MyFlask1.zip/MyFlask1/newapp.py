#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 15:10:28 2019

@author: samsher
"""

from flask import Flask,render_template,url_for,request
import pandas as pd 
import pickle
import requests
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from urllib.request import urlopen
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
from wordcloud import WordCloud, STOPWORDS 
import matplotlib.pyplot as plt
import json
nltk.download('stopwords')

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/index',methods=['POST', 'GET'])
def index():
	return render_template('index.html')
def getnews():
    input_cat = request.form['cat']
    #print(input_cat)
    mylist = []
    news_url = "https://newsapi.org/v2/everything?q=" +input_cat + "&apiKey=c2546ffcabe149f8ac36e61b00440197"
    r = requests.get(url = news_url)
    rIsTrue = pd.notnull(r)
    if rIsTrue :
        result = json.dumps(r.json()) 
        #print(result)
        isResult = pd.notnull(result)
        if isResult : 
            json_data = json.loads(result) 
            isJsonDataTrue = pd.notnull(json_data)
            if isJsonDataTrue :
                if 'articles' in json_data :
                    articles = json_data['articles']
                    #print(articles)
                    isArticlesLen = len(articles)
                    if isArticlesLen == 0:
                        print('No news')
                    if isArticlesLen > 0 :
                        for article in articles:
                            isArticleTrue = pd.notnull(article)
                            if isArticleTrue :
                                if 'description' in article :
                                    description = article['description']
                                    if 'urlToImage' in article :
                                        image = article['urlToImage']
                                        if 'url' in article :
                                            url = article['url']
                                    a = {'description': description, 'url': url, 'image':image}
                                    mylist.append(a)
    return(mylist)
@app.route('/details',methods=['POST', 'GET'])
def details():
    domain_name = request.form['url']
    domain_name = domain_name.split("//");
    domain_name = domain_name[1]
    print(domain_name)
    
    URL = "https://company.clearbit.com/v2/companies/find?domain=www." + domain_name
    r = requests.get(url = URL,headers={'Authorization': 'Bearer sk_9e9888136f145fcab63d5950ae6b877a'})
    
    isTrue = pd.notnull(r)
    subIndustry=""
    location=""
    emailAddress=""
    phoneNumber=""
    isCategoryTrue = False
    isSiteInfoTrue = False
    locationIsTrue = False
    if isTrue:
        result = json.dumps(r.json())    
        isTrue = pd.notnull(result)
        if isTrue:
            json_data = json.loads(result)
            if 'category' in json_data :
                category = json_data['category']
                isCategoryTrue = pd.notnull(category)
            if 'site' in json_data :
                siteInfo = json_data['site']
                isSiteInfoTrue = pd.notnull(siteInfo)
            if 'location' in json_data :
                location = json_data['location']          
                locationIsTrue = pd.notnull(location)
               
        
        if isCategoryTrue:
            subIndustry = category['subIndustry']
            isSubIndustryTrue = pd.notnull(subIndustry)
            if subIndustry is None :
                subIndustry = ""                
                print("sub category - " + subIndustry)
        if location is None:
            location = ""            
            print("Location - " + location)   
        if isSiteInfoTrue :
            phoneNumbers = siteInfo['phoneNumbers']            
            emailAddresses = siteInfo['emailAddresses']
            length_emailAddresses = len(emailAddresses)
            length_phone_num = len(phoneNumbers)
            if length_emailAddresses > 0 :
                print("emails - " + emailAddresses[0])
                emailAddress = emailAddresses[0]
            
            if length_phone_num > 0 :
                print("phones - " + phoneNumbers[0])
                phoneNumber=phoneNumbers[0]
        newsList = getnews()
        print(newsList)
    return render_template('details.html',si=subIndustry,lc=location,eml=emailAddress,phn=phoneNumber,news=newsList)
@app.route('/wordcloud',methods=['POST', 'GET'])
def show():
    tt = request.form['txt']
    ttt = tt.split(" ")
    list = []
    for temp in ttt:
        list.append(temp)
    return render_template('world-cloud.html',txt=list[0:100])

@app.route('/accuracy',methods=['POST', 'GET'])
def next1():
    return render_template('showDetails.html')

@app.route('/confusion',methods=['POST', 'GET'])
def next2():
    return render_template('confusion.html')

@app.route('/next3',methods=['POST', 'GET'])
def next3(): 
    return render_template('next3.html')

@app.route('/report',methods=['POST', 'GET'])
def report():
    return render_template('report.html')

@app.route('/result',methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['name']
    url = message
    try:
        html = urlopen(url).read()
    except:
        st = "false"
        return render_template('result.html',result = st)
    soup = BeautifulSoup(html)
    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()    # rip it out
    # get text
    text = soup.get_text()
    text.strip()
    text.replace("\n"," ")
    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
    text.strip()
    text.replace("\n"," ")
    
    comment_words = text
    stopwords = set(STOPWORDS) 
    wordcloud = WordCloud(width = 800, height = 800, 
    background_color ='white', 
    stopwords = stopwords, 
    min_font_size = 10).generate(comment_words) 
    # plot the WordCloud image                        
    plt.figure(figsize = (8, 8), facecolor = None) 
    plt.imshow(wordcloud) 
    plt.axis("off") 
    plt.tight_layout(pad = 0) 
    plt.savefig(r'/home/samsher/Desktop/MyFlask1/static/images/wordcloud.png')
    
    pridiction_catwise=pd.DataFrame({"Score":[0.64,0.77,0.86,0.60,0.78,0.86,0.55,0.32,0.72,0.89,0.87,0.68,0.89,0.79,0.78,0.8,0.78,0.75,0.8,0.69,0.83,
                                              0.86,0.77,0.65,0.76,0.75,0.78,0.85]},index=["Adult","Arts & Entertainment","Automotive","Beauty & Fitness","Books","Books & Literature","Business & Industry","Career","Career & Education","Computer & Electronics","Finance","Food & Drink","Gambling","Games","Health","Home & Garden","IT Company","Internet & Telecom","Law & Government","News & Media","People & Society","Pets & Animals","Reference","Science","Shopping","Sports","Transportation","Travel"])
    X_in = open('X.pickle','rb')
    y_in = open('labels.pickle','rb')
    X = pickle.load(X_in)
    y = pickle.load(y_in)
    
    classifier = open('svm_classifier.pickle','rb')
    predictor = open('svm_predictions.pickle','rb')
    vectorizer = open('vectorizer.pickle','rb')
    
    clf = pickle.load(classifier)
    pre = pickle.load(predictor)
    vect = pickle.load(vectorizer)

    if request.method == 'POST':
        name = request.form['name']
        data = [text]
        vectarray = vect.transform(data).toarray()
        my_prediction = clf.predict(vectarray)
        my_prediction1=list(my_prediction)
        st="".join(my_prediction1)
        PP=pridiction_catwise.loc[st]
        res=list(PP.values)
        str(res)
    return render_template('result.html',result = st,url = name,score = res,txt=text)



if __name__ == '__main__':
	app.run(debug=True)
