from flask import Flask,render_template,url_for,request
import pandas as pd 
import pickle
import re
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from urllib.request import urlopen
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
nltk.download('stopwords')

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('index.html')
	
@app.route('/accuracy',methods=['POST', 'GET'])
def show():
    return render_template('showDetails.html')

@app.route('/next1',methods=['POST', 'GET'])
def next1():
    return render_template('next1.html')

@app.route('/next2',methods=['POST', 'GET'])
def next2():
    return render_template('next2.html')

@app.route('/next3',methods=['POST', 'GET'])
def next3():
    return render_template('next3.html')

@app.route('/report',methods=['POST', 'GET'])
def report():
    return render_template('report.html')
	
@app.route('/result',methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['name']
    url = message
    try:
      html = urlopen(url).read()
    except:
        st = "false"
        return render_template('result.html',result = st)
    soup = BeautifulSoup(html)
    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()    # rip it out
    # get text
    text = soup.get_text()
    text.strip()
    text.replace("\n"," ")
    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
    text.strip()
    text.replace("\n"," ")
    mydata = pd.read_csv((r"filtered_companies_data.csv"))
    my_newdata = mydata[["description","company_category"]]
    my_newdata.dropna(inplace=True)
    x_description = my_newdata['description']
    y_category =  my_newdata['company_category'] 
    x_description_array=x_description.values
    #y_category_array=y_category.values
    corpus = []
    for i in range(0, len(x_description_array)):
        review = re.sub(r'\W', ' ', str(x_description_array[i])) 
        review = re.sub(r'\d', ' ', review) 
        review = review.lower()
        review = re.sub(r'^br$', ' ', review)
        review = re.sub(r'\s+br\s+',' ',review)
        review = re.sub(r'\s+[a-z]\s+', ' ',review)
        review = re.sub(r'^b\s+', '', review)
        review = re.sub(r'\s+', ' ', review)
        corpus.append(review)
    vectorizer = CountVectorizer(max_features = len(corpus), min_df = 3, max_df = 0.6, stop_words = stopwords.words('english'))
    x_xorpus= vectorizer.fit_transform(corpus).toarray()
    text_train, text_test, sent_train, sent_test = train_test_split(x_xorpus, y_category, test_size = 0.20, random_state = 0)
    classifier = LogisticRegression()
    classifier1=RandomForestClassifier()
    classifier.fit(text_train,sent_train)
    classifier1.fit(text_train,sent_train)
    
	#Alternative Usage of Saved Model
	# joblib.dump(clf, 'NB_spam_model.pkl')
	# NB_spam_model = open('NB_spam_model.pkl','rb')
	# clf = joblib.load(NB_spam_model)

    if request.method == 'POST':
        name = request.form['name']
        data = [text]
        vect = vectorizer.transform(data).toarray()
        my_prediction = classifier.predict(vect)
        my_prediction1=list(my_prediction)
        st="".join(my_prediction1)
    return render_template('result.html',result = st,url = name)



if __name__ == '__main__':
	app.run(debug=True)
